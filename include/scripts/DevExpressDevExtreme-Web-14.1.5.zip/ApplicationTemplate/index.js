$(document).ready(function  () {
	// TODO: add your code here
});