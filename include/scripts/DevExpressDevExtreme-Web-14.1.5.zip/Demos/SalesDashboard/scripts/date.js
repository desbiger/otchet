﻿function getDate() {
    return window.testDate || new Date();
}